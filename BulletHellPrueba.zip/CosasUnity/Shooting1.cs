using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting1 : MonoBehaviour
{
    public GameObject bulletPrefab; // Prefab del Bullet
    public Transform firePoint; // Punto de origen de los disparos
    public float bulletSpeed = 10f; // Velocidad del Bullet
    public float fireRate = 0.5f; // Tiempo entre disparos

    private float nextFireTime = 0f;

    // Start is called before the first frame update
    void Start()
    {
        // Inicializaci�n si es necesario
    }

    // Update is called once per frame
    void Update()
    {
        // Verificar si es tiempo de disparar
        if (Time.time >= nextFireTime)
        {
            Shoot();
            nextFireTime = Time.time + fireRate;
        }
    }

    void Shoot()
    {
        // Instanciar un nuevo Bullet en la posici�n y rotaci�n del firePoint
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);

        // Obtener el Rigidbody del Bullet para aplicarle velocidad
        Rigidbody rb = bullet.GetComponent<Rigidbody>();
        rb.velocity = firePoint.forward * bulletSpeed;

        // Destruir el Bullet despu�s de un tiempo para evitar que siga en la escena
        Destroy(bullet, 5f);
    }
}
