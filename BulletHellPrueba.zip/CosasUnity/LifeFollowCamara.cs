using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LifeObjectPosition2D : MonoBehaviour
{
    public Vector2 offsetFromCorner = new Vector2(1f, 1f); // Desplazamiento desde la esquina
    public Camera mainCamera;

    void Start()
    {
        if (mainCamera == null)
        {
            mainCamera = Camera.main; // Obt�n la c�mara principal si no se asign�
        }
    }

    void Update()
    {
        // Calcula la posici�n de la esquina inferior izquierda de la c�mara en 2D
        Vector3 bottomLeftCorner = mainCamera.ViewportToWorldPoint(new Vector3(0, 0, mainCamera.nearClipPlane));

        // Establece la posici�n del objeto de vida en 2D con un desplazamiento desde la esquina
        transform.position = new Vector3(bottomLeftCorner.x + offsetFromCorner.x, bottomLeftCorner.y + offsetFromCorner.y, 0);
    }
}
