using System.Collections;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootBullet : MonoBehaviour
{
    public GameObject bulletPrefab;  // Prefab de la bala
    public float bulletSpeed = 10f;  // Velocidad de la bala
    public float shootDistance = 1.3f; // Distancia desde el Player donde aparecer� la bala

    void Start()
    {
        // Aqu� puedes inicializar algo si es necesario
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))  // Detecta si se ha hecho clic izquierdo
        {
            Shoot();
        }
    }

    void Shoot()
    {
        // Obt�n la posici�n del rat�n en el mundo
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = 0;  // Asegura que la posici�n z sea 0 para un entorno 2D

        // Calcula la direcci�n hacia la que disparar
        Vector2 direction = (mousePosition - transform.position).normalized;

        // Calcula la posici�n inicial de la bala m�s adelante del player
        Vector3 bulletStartPosition = transform.position + (Vector3)(direction * shootDistance);

        // Instancia la bala
        GameObject bullet = Instantiate(bulletPrefab, bulletStartPosition, Quaternion.identity);

        // Gira el sprite de la bala hacia la direcci�n del disparo
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        bullet.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        // Asigna la direcci�n y velocidad a la bala
        bullet.GetComponent<Rigidbody2D>().velocity = direction * bulletSpeed;
    }
}

