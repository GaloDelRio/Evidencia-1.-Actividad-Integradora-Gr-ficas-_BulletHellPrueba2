using System.Collections;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab; // Prefab del enemigo
    public float spawnInterval = 5f; // Intervalo entre apariciones de enemigos en segundos
    public Vector2 spawnAreaSize = new Vector2(10f, 10f); // Tama�o del �rea de aparici�n en el eje X y Y

    void Start()
    {
        // Comienza la rutina de generaci�n de enemigos
        StartCoroutine(SpawnEnemies());
    }

    IEnumerator SpawnEnemies()
    {
        while (true)
        {
            // Llama al m�todo para generar un enemigo
            SpawnEnemy();

            // Espera durante el intervalo de generaci�n antes de generar el siguiente enemigo
            yield return new WaitForSeconds(spawnInterval);
        }
    }

    void SpawnEnemy()
    {
        // Calcula una posici�n aleatoria dentro del �rea de aparici�n
        Vector2 spawnPosition = new Vector2(
            Random.Range(-spawnAreaSize.x / 2, spawnAreaSize.x / 2),
            Random.Range(-spawnAreaSize.y / 2, spawnAreaSize.y / 2)
        );

        // Instancia el enemigo en la posici�n calculada
        Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
    }
}
