using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    // Inicializar una variable para rastrear el nivel de vida del jugador
    private int playerLifeLevel = 3;

    // M�todo para detectar colisiones con triggers
    void OnTriggerEnter2D(Collider2D collider)
    {
        // Verificamos si el objeto con el que colisiona tiene el tag "Bullet"
        if (collider.CompareTag("Bullet"))
        {
            Debug.Log("El Player ha sido golpeado por una bala!");

            // Eliminar la vida correspondiente seg�n el nivel actual de vida
            switch (playerLifeLevel)
            {
                case 3:
                    DestroyLifeObject("Vida(3)");
                    break;
                case 2:
                    DestroyLifeObject("Vida(2)");
                    break;
                case 1:
                    DestroyLifeObject("Vida(1)");
                    break;
                default:
                    Debug.Log("El Player ya no tiene vidas adicionales.");
                    break;
            }

            // Reducir el nivel de vida despu�s de cada colisi�n
            playerLifeLevel--;

            Destroy(collider.gameObject);
        }
    }

    void DestroyLifeObject(string tag)
    {
        GameObject lifeObject = GameObject.FindWithTag(tag);

        if (lifeObject != null)
        {
            // Destruir el objeto de vida correspondiente
            Destroy(lifeObject);
            Debug.Log("Se ha destruido: " + tag);
        }
        else
        {
            Debug.Log("No se encontr� el objeto de vida con el tag: " + tag);
        }
    }
}
