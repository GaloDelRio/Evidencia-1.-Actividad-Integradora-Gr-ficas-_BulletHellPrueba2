using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingShooter : MonoBehaviour
{
    public GameObject bulletPrefab; // Prefab del Bullet
    public Transform firePoint; // Punto de origen de las balas
    public float moveSpeed = 5f; // Velocidad de movimiento del objeto
    public float fireRate = 0.5f; // Tiempo entre cada disparo
    public float bulletSpeed = 2f; // Velocidad de las balas hacia abajo

    private float nextFireTime = 0f;

    // Start is called before the first frame update
    void Start()
    {
        // Destruir el objeto despu�s de 10 segundos
        Destroy(gameObject, 10f);
    }

    // Update is called once per frame
    void Update()
    {
        // Mover el objeto hacia adelante
        transform.Translate(Vector3.up * moveSpeed * Time.deltaTime);

        // Disparar balas en su camino
        if (Time.time >= nextFireTime)
        {
            Shoot();
            nextFireTime = Time.time + fireRate;
        }
    }

    void Shoot()
    {
        // Instanciar una bala en el firePoint
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);

        // Mover la bala hacia abajo
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.velocity = new Vector2(0, -bulletSpeed);
        }

        // Destruir la bala despu�s de 5 segundos
        Destroy(bullet, 5f);
    }
}
