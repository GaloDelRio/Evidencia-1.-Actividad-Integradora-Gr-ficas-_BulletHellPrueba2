using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC1ConeShoot : MonoBehaviour
{
    public GameObject bulletPrefab; // Prefab del Bullet
    public Transform firePoint; // Punto de origen de los disparos
    public float bulletSpeed = 10f; // Velocidad del Bullet
    public float fireRate = 1f; // Tiempo entre disparos
    public int numberOfBullets = 8; // N�mero de balas en el cono
    public float coneAngle = 45f; // �ngulo del cono en grados
    public Transform target; // Entidad a la que apuntar (por defecto, el Player)

    private float nextFireTime = 0f;

    // Start is called before the first frame update
    void Start()
    {
        // Inicializaci�n si es necesario
    }

    // Update is called once per frame
    void Update()
    {
        // Verificar si es tiempo de disparar
        if (Time.time >= nextFireTime)
        {
            ShootInCone();
            nextFireTime = Time.time + fireRate;
        }
    }

    void ShootInCone()
    {
        if (target == null) return;

        Vector2 targetDirection = (target.position - firePoint.position).normalized; // Direcci�n hacia el objetivo
        float startAngle = -coneAngle / 2f; // �ngulo inicial del cono
        float angleStep = coneAngle / (numberOfBullets - 1); // Paso del �ngulo entre balas

        // Disparar balas en un patr�n de cono
        for (int i = 0; i < numberOfBullets; i++)
        {
            // Calcular el �ngulo para la posici�n de la bala
            float angle = startAngle + (angleStep * i);
            Vector2 coneDirection = Quaternion.Euler(0, 0, angle) * targetDirection;

            // Instanciar un nuevo Bullet en la posici�n del firePoint
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);

            // Obtener el Rigidbody del Bullet
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

            // Aplicar velocidad al Bullet en la direcci�n calculada
            rb.velocity = coneDirection * bulletSpeed;

            // Destruir el Bullet despu�s de un tiempo para evitar que siga en la escena
            Destroy(bullet, 2f);
        }
    }
}
