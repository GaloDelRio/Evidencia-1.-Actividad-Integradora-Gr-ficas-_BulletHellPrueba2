using UnityEngine;

public class NPCShoot : MonoBehaviour
{
    public GameObject bulletPrefab; // Prefab de la bala
    public float shootInterval = 0.1f; // Intervalo entre disparos
    public float angleChangeSpeed = 120f; // Velocidad de cambio de �ngulo en grados por segundo (m�s r�pido)
    public float bulletSpeed = 5f; // Velocidad de la bala
    public float bulletLifetime = 2f; // Tiempo en segundos que la bala permanece activa

    private float currentAngle = 0f; // �ngulo actual de disparo

    void Start()
    {
        InvokeRepeating("ShootBullet", 0f, shootInterval);
    }

    void ShootBullet()
    {
        // Crear una bala
        GameObject bullet = Instantiate(bulletPrefab, transform.position, Quaternion.identity);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

        if (rb != null)
        {
            // Convertir el �ngulo actual a radianes
            float angleInRadians = currentAngle * Mathf.Deg2Rad;
            // Calcular la direcci�n de la bala
            Vector2 direction = new Vector2(Mathf.Cos(angleInRadians), Mathf.Sin(angleInRadians));
            // Asignar la direcci�n y velocidad a la bala
            rb.velocity = direction * bulletSpeed;
        }

        // Configurar el tiempo de vida de la bala
        Destroy(bullet, bulletLifetime);

        // Cambiar el �ngulo para el pr�ximo disparo
        currentAngle += angleChangeSpeed * shootInterval;
        if (currentAngle >= 360f)
        {
            currentAngle -= 360f;
        }
    }
}
