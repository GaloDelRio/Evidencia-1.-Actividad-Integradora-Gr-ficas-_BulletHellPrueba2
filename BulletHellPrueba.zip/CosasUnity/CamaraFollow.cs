using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player; // Referencia al transform del Player
    public Vector3 offset; // Desplazamiento de la c�mara respecto al Player

    // Update is called once per frame
    void Update()
    {
        // Actualizar la posici�n de la c�mara en base a la posici�n del Player m�s el offset
        Vector3 newPosition = player.position + offset;
        newPosition.z = transform.position.z; // Mantener la c�mara en el mismo plano Z
        transform.position = newPosition;

        // Opcional: Si quieres que la c�mara siempre mire hacia el Player en 2D, puedes usar transform.LookAt()
        //transform.LookAt(player);
    }
}
