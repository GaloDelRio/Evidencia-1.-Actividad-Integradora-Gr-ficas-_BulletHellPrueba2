using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    public Transform player; // Referencia al transform del Player
    public float speed = 3f; // Velocidad de movimiento del NPC

    // Start is called before the first frame update
    void Start()
    {
        // Inicializaci�n si es necesario
    }

    // Update is called once per frame
    void Update()
    {
        // Calcular la direcci�n hacia el Player
        Vector3 direction = (player.position - transform.position).normalized;

        // Mover al NPC hacia el Player de forma constante
        transform.position += direction * speed * Time.deltaTime;

        // Mantener la rotaci�n original del NPC (en caso de necesitarlo en el plano 2D)
        Quaternion originalRotation = transform.rotation;
        originalRotation.x = 0;
        originalRotation.y = 0; // Asegura que no gire en el eje Y en 2D
        transform.rotation = originalRotation;
    }
}
