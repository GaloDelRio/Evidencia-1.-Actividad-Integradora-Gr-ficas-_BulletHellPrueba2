using UnityEngine;
using UnityEngine.SceneManagement; // Necesario para manejar escenas

public class Bullet : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D collision)
    {
        // Verifica si la bala ha colisionado con un enemigo
        if (collision.CompareTag("Enemy"))
        {
            // Imprime un mensaje en la consola
            Debug.Log("�Colisi�n con enemigo detectada!");

            // Destruye al enemigo
            Destroy(collision.gameObject);

            // Destruye la bala
            Destroy(gameObject);
        }
        else if (collision.CompareTag("Boss"))
        {
            // Imprime un mensaje en la consola
            Debug.Log("�Colisi�n con jefe detectada!");

            // Destruye al jefe
            Destroy(collision.gameObject);

            // Llama a EndGame para terminar el juego
            EndGame();
        }
    }

    void EndGame()
    {
        // Mostrar un mensaje en la consola
        Debug.Log("SAT ha sido eliminado. Fin del juego.");

        // Verificar si estamos en el editor
        #if UNITY_EDITOR
        // En el editor, parar la reproducci�n
        UnityEditor.EditorApplication.isPlaying = false;

        #else
        // En una compilaci�n, cerrar la aplicaci�n
        Application.Quit();
        #endif
    }
}
