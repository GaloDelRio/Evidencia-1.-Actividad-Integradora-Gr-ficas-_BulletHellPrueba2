using UnityEngine;

public class MovePlayer : MonoBehaviour
{
    public float speed = 5f; // Velocidad de movimiento del jugador
    public float slowSpeed = 2.5f; // Velocidad reducida

    void Update()
    {
        // Obtener la entrada del usuario en los ejes horizontales y verticales
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        // Crear un vector de movimiento basado en la entrada
        Vector3 movement = new Vector3(moveHorizontal, moveVertical, 0.0f);

        // Verificar si la tecla "l" est� presionada para reducir la velocidad
        if (Input.GetKey(KeyCode.L))
        {
            transform.Translate(movement * slowSpeed * Time.deltaTime, Space.World);
        }
        else
        {
            // Mover al jugador en funci�n del vector de movimiento y la velocidad normal
            transform.Translate(movement * speed * Time.deltaTime, Space.World);
        }
    }
}
