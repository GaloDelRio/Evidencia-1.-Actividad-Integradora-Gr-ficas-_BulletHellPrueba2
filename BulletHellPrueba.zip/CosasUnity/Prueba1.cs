using UnityEngine;
using System.Collections;

public class NPCStarShoot : MonoBehaviour
{
    public GameObject starBulletPrefab; // Prefab de la bala para el patr�n de estrella
    public float shootRate = 0.1f; // Intervalo entre disparos
    public float starAngleChangeSpeed = 60f; // Velocidad de cambio de �ngulo en grados por segundo para el patr�n de estrella
    public float starBulletSpeed = 5f; // Velocidad de las balas en el patr�n de estrella
    public float starBulletLifetime = 2f; // Tiempo en segundos que la bala permanece activa en el patr�n de estrella
    public int pointsInStar = 5; // N�mero de puntos en el patr�n de estrella
    public float shootDuration = 5f; // Duraci�n del disparo en segundos
    public float pauseDuration = 2f; // Duraci�n de la pausa en segundos

    private float currentStarAngle = 0f; // �ngulo actual de disparo para el patr�n de estrella
    private bool isShooting = false;

    void Start()
    {
        StartCoroutine(ShootPatternCoroutine());
    }

    IEnumerator ShootPatternCoroutine()
    {
        while (true)
        {
            isShooting = true;
            float startTime = Time.time;

            // Disparar balas durante el tiempo especificado
            while (Time.time - startTime < shootDuration)
            {
                ShootStarPattern();
                yield return new WaitForSeconds(shootRate); // Espera entre disparos
            }

            // Detener el disparo
            isShooting = false;

            // Pausa antes de repetir
            yield return new WaitForSeconds(pauseDuration);
        }
    }

    void ShootStarPattern()
    {
        float angleStep = 360f / pointsInStar; // �ngulo entre puntos de la estrella

        for (int i = 0; i < pointsInStar; i++)
        {
            float bulletAngle = currentStarAngle + i * angleStep;

            // Crear una bala
            GameObject bullet = Instantiate(starBulletPrefab, transform.position, Quaternion.identity);
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

            if (rb != null)
            {
                // Convertir el �ngulo a radianes
                float angleInRadians = bulletAngle * Mathf.Deg2Rad;
                // Calcular la direcci�n de la bala
                Vector2 direction = new Vector2(Mathf.Cos(angleInRadians), Mathf.Sin(angleInRadians));
                // Asignar la direcci�n y velocidad a la bala
                rb.velocity = direction * starBulletSpeed;
            }

            // Configurar el tiempo de vida de la bala
            Destroy(bullet, starBulletLifetime);
        }

        // Cambiar el �ngulo para el pr�ximo disparo
        currentStarAngle += starAngleChangeSpeed * shootRate;
        if (currentStarAngle >= 360f)
        {
            currentStarAngle -= 360f;
        }
    }
}
