using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC1StarShoot : MonoBehaviour
{
    public GameObject bulletPrefab; // Prefab del Bullet
    public Transform firePoint; // Punto de origen de los disparos
    public float bulletSpeed = 10f; // Velocidad del Bullet
    public float fireRate = 1f; // Tiempo entre disparos
    public int numberOfPoints = 5; // N�mero de puntos de la estrella
    public float starRadius = 5f; // Radio de la estrella

    private float nextFireTime = 0f;

    // Start is called before the first frame update
    void Start()
    {
        // Inicializaci�n si es necesario
    }

    // Update is called once per frame
    void Update()
    {
        // Verificar si es tiempo de disparar
        if (Time.time >= nextFireTime)
        {
            ShootStarPattern();
            nextFireTime = Time.time + fireRate;
        }
    }

    void ShootStarPattern()
    {
        float angleStep = 360f / numberOfPoints; // �ngulo entre cada punto de la estrella

        // Disparar balas en un patr�n de estrella
        for (int i = 0; i < numberOfPoints; i++)
        {
            // Calcular el �ngulo para la posici�n de la bala
            float angle = i * angleStep;
            Vector2 direction = new Vector2(Mathf.Cos(Mathf.Deg2Rad * angle), Mathf.Sin(Mathf.Deg2Rad * angle)) * starRadius;

            // Instanciar un nuevo Bullet en la posici�n del firePoint
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);

            // Obtener el Rigidbody del Bullet
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

            // Aplicar velocidad al Bullet en la direcci�n calculada
            rb.velocity = direction.normalized * bulletSpeed;

            // Destruir el Bullet despu�s de un tiempo para evitar que siga en la escena
            Destroy(bullet, 2f);
        }
    }
}
